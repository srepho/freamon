"""Integration modules for connecting Freamon with external libraries.

This package provides integration points between Freamon and various external
libraries and systems for enhanced functionality.
"""