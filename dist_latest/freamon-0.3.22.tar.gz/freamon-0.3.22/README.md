# freamon

<p align="center">
  <img src="package_logo.webp" alt="Freamon Logo" width="250"/>
</p>

[![PyPI version](https://img.shields.io/pypi/v/freamon.svg)](https://pypi.org/project/freamon/)
[![GitHub release](https://img.shields.io/github/v/release/srepho/freamon)](https://github.com/srepho/freamon/releases)

A package to make data science projects on tabular data easier. Named after the great character from The Wire played by Clarke Peters. Featuring advanced data type detection with support for Australian data patterns.

## Features

- **Data Quality Assessment:** Missing values, outliers, data types, duplicates
- **Advanced Data Type Detection:** 
  - Semantic type identification including Australian-specific data patterns (postcodes, ABNs, ACNs, phone numbers)
  - Mixed date format detection and intelligent multi-pass conversion
  - Scientific notation detection and preservation
  - Special character handling (_, $, %, etc.) in column names and values
- **Text Deduplication:**
  - Exact deduplication with hash-based methods
  - Fuzzy deduplication with similarity metrics
  - LSH (Locality-Sensitive Hashing) for efficient similarity search
  - Hierarchical clustering for duplicate detection
- **Exploratory Data Analysis (EDA):** 
  - Statistical analysis and visualizations
  - Interactive HTML reports with lazy loading
  - Jupyter notebook export
  - Markdown report generation
- **Feature Engineering:** 
  - **Standard Features:** Polynomial, interaction, datetime, binned features
  - **Automatic Interaction Detection:** ShapIQ-based automatic feature engineering  
  - **Time Series Feature Engineering:** Automated lag detection, rolling windows, differencing
- **Categorical Encoding:** 
  - **Basic Encoders:** One-hot, ordinal, target encoding
  - **Advanced Encoders:** Binary, hashing, weight of evidence (WOE) encoding
- **Text Processing:** Basic NLP with optional spaCy integration
- **Model Selection:** Train/test splitting with time-series awareness
- **Modeling:** Training, evaluation, and validation
  - **Support for Multiple Libraries:** scikit-learn, LightGBM, XGBoost, CatBoost
  - **Intelligent Hyperparameter Tuning:** Parameter-importance aware tuning for LightGBM
  - **Cross-Validation:** Training with cross-validation as the standard approach
    - **Multiple Strategies:** K-fold, stratified, time series, and walk-forward validation
    - **Ensemble Methods:** Combine models from different folds for improved performance
- **Explainability:** 
  - **SHAP Support:** Feature importance and explanations
  - **ShapIQ Integration:** Feature interactions detection and visualization
  - **Interactive Reports:** HTML reports for explainability findings
  - **Permutation Importance:** Better feature importance for black-box models
- **Pipeline System:**
  - **Integrated Workflow:** Connect feature engineering, selection, and modeling
  - **Modular Design:** Mix and match steps for custom workflows
  - **Persistence:** Save and load complete pipelines
  - **Visualization:** Pipeline visualization with multiple backends
- **Multiple DataFrame Backends:** 
  - **Pandas:** Standard interface
  - **Polars:** High-performance alternative
  - **Dask:** Out-of-core processing for large datasets

## Installation

```bash
# Basic installation
pip install freamon==0.3.22

# With all optional dependencies (no development tools)
pip install freamon[all]==0.3.22

# With all dependencies including development tools
pip install freamon[full]

# With specific optional dependencies
pip install freamon[lightgbm]        # For LightGBM support
pip install freamon[xgboost]         # For XGBoost support
pip install freamon[catboost]        # For CatBoost support
pip install freamon[nlp]             # For NLP capabilities with spaCy
pip install freamon[polars]          # For Polars support
pip install freamon[dask]            # For Dask support
pip install freamon[explainability]  # For SHAP and ShapIQ integration
pip install freamon[visualization]   # For pipeline visualization with Graphviz
pip install freamon[tuning]          # For hyperparameter tuning support

# Development installation
git clone https://github.com/yourusername/freamon.git
cd freamon
pip install -e ".[dev,all]"  # Or use pip install -e ".[full]" for all dependencies
```

## Quick Start

### LSH Text Deduplication (New!)

```python
import pandas as pd
from freamon.deduplication import lsh_deduplication

# Load text data
df = pd.read_csv("articles.csv")

# Find unique texts using LSH
unique_indices = lsh_deduplication(
    df['content'],
    threshold=0.8,               # Similarity threshold (0-1)
    num_minhash_permutations=100,  # MinHash signatures (more = higher accuracy)
    num_bands=20,                # Number of bands (more = higher recall)
    preprocess=True,             # Preprocess text before comparison
    keep='longest'               # Keep longest version of duplicates
)

# Get deduplicated dataframe
df_unique = df.iloc[unique_indices].copy()
print(f"Reduced from {len(df)} to {len(df_unique)} documents")
print(f"Found {len(df) - len(df_unique)} duplicates ({(len(df) - len(df_unique)) / len(df) * 100:.1f}%)")

# Get similarity information
unique_indices, similarity_dict = lsh_deduplication(
    df['content'],
    threshold=0.8,
    return_similarity_dict=True
)

# Examine similar documents for a specific document (e.g., document 42)
similar_docs = similarity_dict.get(42, [])
print(f"Documents similar to #42: {similar_docs}")
```

### DataType Detection with Special Character Support

```python
import pandas as pd
import numpy as np
from freamon.utils.datatype_detector import DataTypeDetector
from freamon.eda.analyzer import EDAAnalyzer

# Sample data with special characters in column names
data = {
    'price_$': [199.99, 299.99, 149.99, 399.99, 249.99],
    'growth_%': [5.2, -1.8, 10.5, 3.7, 0.0],
    'rating_^_5': [4.5, 3.8, 4.2, 4.7, 3.5],
    'mixed_dates': ['2023-01-15', '01/20/2023', '2/15/23', '2023-02-28', '3/1/2023'],
    'australian_postcodes': ['2000', '3000', '4000', '5000', '6000'],
    'excel_dates': [44927, 44928, 44929, 44930, 44931],  # Excel dates
}
df = pd.DataFrame(data)

# Initialize detector
detector = DataTypeDetector(
    df,
    detect_semantic_types=True,    # Enable semantic type detection
    distinguish_numeric=True       # Distinguish between categorical and continuous numeric
)

# Detect all types
detector.detect_all_types()

# View detected types - special characters in column names are preserved
print("\nDetected Column Types:")
for col, type_info in detector.column_types.items():
    print(f"{col}: {type_info}")

# Save HTML report - special characters will display correctly
report_html = detector.get_column_report_html()
with open("datatype_detection_report.html", "w") as f:
    f.write(report_html)

# Generate EDA report - special characters will display correctly
analyzer = EDAAnalyzer(df)
analyzer.run_full_analysis(
    output_path="financial_data_report.html",
    title="Financial Data Analysis"
)
```

### Time Series Modeling and Visualization

```python
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from freamon.modeling.helpers import create_lightgbm_regressor
from freamon.model_selection.cross_validation import time_series_cross_validate
from freamon.modeling.visualization import (
    plot_cv_metrics,
    plot_feature_importance, 
    plot_importance_by_groups,
    plot_time_series_predictions
)

# Create time series data with date, target and text features
def create_sample_data(n_days=365):
    start_date = datetime(2023, 1, 1)
    dates = [start_date + timedelta(days=i) for i in range(n_days)]
    
    # Create trend and seasonal components
    trend = np.linspace(100, 200, n_days)
    weekly = 15 * np.sin(2 * np.pi * np.arange(n_days) / 7)
    monthly = 30 * np.sin(2 * np.pi * np.arange(n_days) / 30)
    noise = np.random.normal(0, 10, n_days)
    
    # Target variable
    values = trend + weekly + monthly + noise
    
    # Text features (simulated)
    sentiments = np.random.choice(['positive', 'neutral', 'negative'], n_days, p=[0.3, 0.5, 0.2])
    topics = np.random.choice(['finance', 'technology', 'retail', 'healthcare'], n_days)
    
    return pd.DataFrame({
        'date': dates,
        'target': values,
        'sentiment': sentiments,
        'topic': topics,
        'text_length': np.random.randint(50, 500, n_days)
    })

# Create dataset and prepare features
df = create_sample_data()
print(f"Dataset created with {len(df)} observations")

# Feature engineering - create time-based features
df['dayofweek'] = df['date'].dt.dayofweek
df['month'] = df['date'].dt.month
df['day'] = df['date'].dt.day
df['is_weekend'] = (df['dayofweek'] >= 5).astype(int)

# Create lag features
for lag in [1, 2, 3, 7, 14]:
    df[f'target_lag_{lag}'] = df['target'].shift(lag)

# Create rolling window features
for window in [3, 7, 14]:
    df[f'target_roll_mean_{window}'] = df['target'].rolling(window=window).mean()
    df[f'target_roll_std_{window}'] = df['target'].rolling(window=window).std()

# Encode categorical variables
df = pd.get_dummies(df, columns=['sentiment', 'topic'], drop_first=True)

# Drop NAs from lag features
df = df.dropna()

# Define features and target
features = [col for col in df.columns if col not in ['date', 'target']]
X = df[features]
y = df['target']
date_col = df['date']

# Create LightGBM regressor with simplified helper function
model = create_lightgbm_regressor(num_leaves=31, learning_rate=0.1)

# Perform time series cross-validation with expanding window
cv_results = time_series_cross_validate(
    model, X, y, date_col,
    initial_window=0.5, 
    step=30,
    save_predictions=True
)

# Visualize cross-validation metrics
plot_cv_metrics(cv_results)

# Visualize feature importance from the last fold's model
plot_feature_importance(cv_results['models'][-1], X.columns, top_n=15)

# Group features by type and visualize importance by groups
feature_groups = {
    'time_features': ['dayofweek', 'month', 'day', 'is_weekend'],
    'lag_features': [col for col in X.columns if 'lag' in col],
    'rolling_features': [col for col in X.columns if 'roll' in col],
    'text_features': ['text_length'] + [col for col in X.columns if 'sentiment' in col or 'topic' in col]
}

plot_importance_by_groups(cv_results['models'][-1], X.columns, feature_groups)

# Visualize predictions from cross-validation
plot_time_series_predictions(
    date_col[cv_results['test_indices'][-1]],
    y.iloc[cv_results['test_indices'][-1]],
    cv_results['predictions'][-1]
)

# Final model training on all data
final_model = create_lightgbm_regressor(num_leaves=31, learning_rate=0.1)
final_model.fit(X, y)
```

### Markdown Report Generation

```python
import pandas as pd
import numpy as np
from freamon.eda.markdown_report import generate_markdown_report

# Create sample data
data = {
    'age': np.random.randint(18, 70, 100),
    'income': np.random.normal(50000, 15000, 100),
    'education': np.random.choice(['High School', 'Bachelor', 'Master', 'PhD'], 100),
    'experience': np.random.randint(0, 30, 100),
    'satisfaction': np.random.choice(['Low', 'Medium', 'High'], 100),
    'churn': np.random.choice([0, 1], 100, p=[0.8, 0.2])
}
df = pd.DataFrame(data)

# Generate markdown report
report = generate_markdown_report(
    df, 
    title="Customer Analysis Report",
    description="Analysis of customer demographics and churn risk",
    target_column='churn',
    include_correlations=True,
    include_histograms=True,
    include_boxplots=True
)

# Save markdown report
with open("customer_analysis.md", "w") as f:
    f.write(report)

# Convert to HTML (optional)
from markdown import markdown
html = markdown(report)
with open("customer_analysis.html", "w") as f:
    f.write(html)
```

## Version 0.3.22 Highlights

- **LSH Deduplication for Text Data:**
  - Efficient similarity search without all-pairs comparison
  - MinHash signatures for Jaccard similarity approximation
  - Banding technique for similarity-based bucketing
  - Parameter tuning for precision/recall tradeoffs
  
- **Special Character Handling in Reports:**
  - Fixed display of column names with special characters (_, $, %, ^, etc.)
  - Proper rendering of currency symbols and percentages in plots
  - Automatic patching of datatype detection reports
  - Compatible with existing code through function wrapping
  
- **Markdown Report Generation:**
  - Generate clean, readable markdown reports from data analysis
  - Include tables, statistics, and embedded image links
  - Customizable sections and analysis depth
  - Convert to HTML, PDF, or other formats for sharing

## Module Overview

- **data_quality:** Tools for assessing and improving data quality
  - **drift:** Data drift detection and monitoring
  - **outliers:** Outlier detection and handling
  - **missing_values:** Missing value analysis and imputation
- **deduplication:** Text deduplication and similarity search
  - **exact_deduplication:** Hash-based exact matching
  - **fuzzy_deduplication:** Similarity-based matching
  - **lsh_deduplication:** Locality-Sensitive Hashing for efficient matching
  - **clustering:** Hierarchical clustering for duplicate detection
- **eda:** Exploratory data analysis tools
  - **analyzer:** Comprehensive EDA with HTML reporting and Jupyter export
  - **markdown_report:** Generate lightweight markdown reports
  - **time_series:** Enhanced time series analysis, seasonality, stationarity, and forecasting
  - **report:** Interactive HTML reports with lazy loading for large datasets
- **features:** Feature engineering utilities
  - **engineer:** Standard feature transformations
  - **shapiq_engineer:** Automatic feature interaction detection
  - **time_series_engineer:** Automated time series feature generation
- **utils:** Utility functions for working with dataframes and encoders
  - **dataframe_utils:** Tools for different dataframe backends and date detection
  - **datatype_detector:** Advanced data type detection and conversion
  - **matplotlib_fixes:** Special character handling in plots and reports
  - **encoders:** Categorical variable encoding tools with cross-validation support
  - **text_utils:** Text processing utilities with fit/transform capability for TF-IDF and bag-of-words features
- **model_selection:** Methods for splitting data and cross-validation
  - **cross_validation:** Standard and time series cross-validation tools
  - **cv_trainer:** Cross-validated model training with ensemble methods
  - **splitter:** Train/test splitting with special modes for time series
- **modeling:** Model training, evaluation, and comparison
  - **model:** Base model class with consistent interface
  - **factory:** Model creation utilities for multiple libraries
  - **trainer:** Training and evaluation tools
  - **lightgbm:** High-level LightGBM interface with intelligent tuning
  - **tuning:** Hyperparameter optimization with parameter importance awareness
  - **importance:** Permutation-based feature importance
  - **calibration:** Probability calibration for classification models
  - **helpers:** Simplified model creation functions with sensible defaults
  - **visualization:** Tools for visualizing model performance, feature importance, and predictions
- **pipeline:** Integrated workflow system connecting feature engineering with model training
  - **pipeline:** Core Pipeline interface
  - **steps:** Reusable pipeline steps for different tasks
  - **visualization:** Pipeline visualization tools
  - **cross_validation:** Cross-validation training in pipelines
- **integration:** Optional integrations with other tools and libraries
  - **allyanonimiser_bridge:** Bridge to anonymization tools

Check out the [ROADMAP.md](ROADMAP.md) file for information on planned features and development phases.

## Example Scripts

The package includes several example scripts to demonstrate its functionality:

- **lsh_deduplication_example.py** - Efficient text deduplication with LSH
- **datatype_special_chars_example.py** - Handling special characters in column names and values
- **text_time_series_regression_example.py** - Advanced time series modeling with LightGBM and visualization
- **markdown_report_example.py** - Generate markdown reports from data analysis
- **lightgbm_simplified_example.py** - Simplified LightGBM model creation with helper functions
- **threshold_optimization_example.py** - Classification threshold optimization
- **shapiq_example.py** - Feature interaction detection with ShapIQ
- **pipeline_example.py** - Complete modeling pipeline
- **automated_end_to_end_pipeline.py** - Fully automated modeling workflow
- **drift_and_visualization_example.py** - Data drift detection and visualization
- **time_series_enhanced_example.py** - Advanced time series features
- **text_analytics_example.py** - Text processing and feature extraction
- **multivariate_analysis_example.py** - Multivariate feature exploration
- **mixed_date_formats_example.py** - Handling date columns with multiple formats
- **scientific_notation_example.py** - Detecting and visualizing scientific notation data
- **datatype_detector_example.py** - Optimized data type detection for large datasets
- **large_dataset_eda_example.py** - Enhanced EDA reporting for large datasets with lazy loading
- **jupyter_export_example.py** - Export EDA reports to Jupyter notebooks for interactive analysis

Run any example by navigating to the examples directory and executing:

```bash
python example_name.py
```

## Additional Documentation

- [LSH Deduplication Guide](README_LSH_DEDUPLICATION.md) - Detailed guide to LSH-based text deduplication
- [DataType Fixes](README_DATATYPE_FIX.md) - Documentation on special character handling in reports
- [Deduplication Overview](README_DEDUPLICATION.md) - General overview of deduplication capabilities
- [Deduplication Tracking](README_DEDUPLICATION_TRACKING.md) - Tracking index changes during deduplication

## Development

To contribute to freamon, install the development dependencies:

```bash
# Install development dependencies only
pip install -e ".[dev]"

# Install all dependencies (including dev tools)
pip install -e ".[full]"
```

Run tests:

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=freamon

# Run specific tests
pytest tests/test_datatype_detector_performance.py
```

## License

MIT License